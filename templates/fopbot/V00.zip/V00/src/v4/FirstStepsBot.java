package v4;

import fopbot.*;
import static fopbot.Direction.*;

public class FirstStepsBot {

	public static void main(String[] args) {
		World.setSize(10, 10);
		World.setDelay(200);
		World.setVisible(true);
		World.putCoins(4,7, 1);
		
		// TODO: V4

	}

}
