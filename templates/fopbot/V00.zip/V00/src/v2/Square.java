package v2;

import fopbot.*;
import static fopbot.Direction.*;

public class Square {

	public static void main(String[] args) {
		World.setSize(10, 10);
		World.setDelay(100);
		World.setVisible(true);

		// TODO: V2 insert your code here

	}

}
