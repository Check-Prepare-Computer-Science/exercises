package vueb;

import fopbot.*;
import static fopbot.Direction.*;

public class Vorlage {

	public static void main(String[] args) {
		World.setSize(10, 10);
		World.setDelay(200);
		World.setVisible(true);
		
		Robot r1 = new Robot(4,4, RIGHT, 99);
		r1.move();
	}

}
